#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include "Grafo.hpp"
#include "Pacote.hpp"
#include "Armazem.hpp"
#include "Simulacao.hpp"

#define SUCESSO 0
#define NO_FILE_ERROR 1

int main(int argc, char* argv[]) {
    std::cout << std::setfill('0') << std::setw(7);

    if (argc < 2) {
        std::cerr << "Erro: você deve fornecer o caminho do arquivo como argumento.\n";
        return NO_FILE_ERROR;
    }

    std::ifstream inputFile(argv[1]);
    if (!inputFile.is_open()) {
        std::cerr << "Erro ao abrir o arquivo: " << argv[1] << "\n";
        return NO_FILE_ERROR;
    }

    // Leitura dos parâmetros gerais
    int capacidade, latencia, intervalo, custo_remocao;
    inputFile >> capacidade >> latencia >> intervalo >> custo_remocao;

    // Leitura da quantidade de armazéns e configuração do grafo
    int numArmazens;
    inputFile >> numArmazens;

    Grafo grafo(numArmazens);
    Armazem** armazens = new Armazem*[numArmazens];

    for (int i = 0; i < numArmazens; i++) {
        for (int j = 0; j < numArmazens; j++) {
            int aresta;
            inputFile >> aresta;
            if (aresta) {
                grafo.adicionarAresta(i, j);
            }
        }
        armazens[i] = new Armazem(i, numArmazens);
    }

    // Leitura dos pacotes
    int numPac;
    inputFile >> numPac;

    Pacote** pacs = new Pacote*[numPac];
    int* tempoChegada = new int[numPac];
    int* origem = new int[numPac];
    int* destino = new int[numPac];

    std::string dummy;
    int idLido;

    for (int i = 0; i < numPac; i++) {
        inputFile >> tempoChegada[i];
        inputFile >> dummy >> idLido;
        inputFile >> dummy >> origem[i];
        inputFile >> dummy >> destino[i];
        pacs[i] = new Pacote(i, tempoChegada[i], origem[i], destino[i]);
    }

    // Cálculo dos caminhos
    Fila<int>* caminho = new Fila<int>[numPac];
    for (int i = 0; i < numPac; i++) {
        int tamCaminho;
        int* caminhoVet = grafo.menorCaminho(origem[i], destino[i], tamCaminho);
        if (caminhoVet != nullptr) {
            for (int j = 0; j < tamCaminho; j++) {
                caminho[i].push(caminhoVet[j]);
            }
            delete[] caminhoVet;
        }
    }

    // Chama a simulação
    Simulacao simulacao;
    simulacao.executar(
        capacidade, latencia, intervalo, custo_remocao,
        numArmazens, armazens, numPac, pacs, caminho
    );

    // Liberação de memória
    for (int i = 0; i < numPac; i++) delete pacs[i];
    delete[] pacs;
    for (int i = 0; i < numArmazens; i++) delete armazens[i];
    delete[] armazens;
    delete[] caminho;
    delete[] tempoChegada;
    delete[] origem;
    delete[] destino;

    return SUCESSO;
}