#include "Evento.hpp"
#include <iostream>
#include <iomanip>

void Evento::imprimirArmazenado(int tempo, Pacote* pacote, int idArmazem, int secao, bool rearm) {
    std::cout << std::setfill('0') << std::setw(7) << tempo << " "
              << "pacote " << std::setw(3) << pacote->getIdPacote() << " "
              << (rearm ? "rearmazenado" : "armazenado") << " em "
              << std::setw(3) << idArmazem << " na secao "
              << std::setw(3) << secao << "\n";
}

void Evento::imprimirEntregue(int tempo, Pacote* pacote, int idArmazem) {
    std::cout << std::setfill('0') << std::setw(7) << tempo << " "
              << "pacote " << std::setw(3) << pacote->getIdPacote() << " "
              << "entregue em " << std::setw(3) << idArmazem << "\n";
}

void Evento::imprimirRemovido(int tempo, Pacote* pacote, int idArmazem, int secao) {
    std::cout << std::setfill('0') << std::setw(7) << tempo << " "
              << "pacote " << std::setw(3) << pacote->getIdPacote() << " "
              << "removido de " << std::setw(3) << idArmazem << " na secao "
              << std::setw(3) << secao << "\n";
}

void Evento::imprimirTransporte(int tempo, Pacote* pacote, int idArmazem, int proximoArmazem) {
    std::cout << std::setfill('0') << std::setw(7) << tempo << " "
              << "pacote " << std::setw(3) << pacote->getIdPacote() << " "
              << "em transito de " << std::setw(3) << idArmazem << " para "
              << std::setw(3) << proximoArmazem << "\n";
}