#include "Grafo.hpp"
#include <iostream>

// Construtor do Grafo
// Inicializa a matriz de adjacência quadrada com zeros
Grafo::Grafo(int numVertices) {
    this->numVertices = numVertices;

    // Aloca um array de ponteiros (linhas)
    matrizAdj = new int*[numVertices];
    
    for (int i = 0; i < numVertices; i++) {
        // Para cada linha, aloca um array de inteiros (colunas)
        matrizAdj[i] = new int[numVertices];

        // Inicializa todas as posições da linha com zero (sem aresta)
        for (int j = 0; j < numVertices; j++) {
            matrizAdj[i][j] = 0;
        }
    }
}

// Destrutor do Grafo
// Libera a memória da matriz alocada
Grafo::~Grafo() {
    for (int i = 0; i < numVertices; i++) {
        delete[] matrizAdj[i];  // libera cada linha
    }
    delete[] matrizAdj;  // libera o array de linhas
}

// Adiciona uma aresta de 'origem' para 'destino' com peso opcional (default = 1)
void Grafo::adicionarAresta(int origem, int destino, int peso) {
    if (origem >= 0 && origem < numVertices && destino >= 0 && destino < numVertices) {
        matrizAdj[origem][destino] = peso;
    }
}

// Remove a aresta de 'origem' para 'destino' (definindo peso como zero)
void Grafo::removerAresta(int origem, int destino) {
    if (origem >= 0 && origem < numVertices && destino >= 0 && destino < numVertices) {
        matrizAdj[origem][destino] = 0;
    }
}

// Verifica se existe uma aresta de 'origem' para 'destino'
bool Grafo::existeAresta(int origem, int destino) {
    if (origem >= 0 && origem < numVertices && destino >= 0 && destino < numVertices) {
        return matrizAdj[origem][destino] != 0;
    }
    return false;
}

// Imprime a matriz de adjacência (todos os pesos)
void Grafo::imprimirMatriz() {
    for (int i = 0; i < numVertices; i++) {
        for (int j = 0; j < numVertices; j++) {
            std::cout << matrizAdj[i][j] << " ";
        }
        std::cout << "\n";  // linha nova para melhor visualização
    }
}

// Retorna um array com o menor caminho de 'inicio' até 'fim' usando BFS
// tamanhoCaminho é passado por referência e recebe o tamanho do caminho
int* Grafo::menorCaminho(int inicio, int fim, int& tamanhoCaminho) {
    int* caminho = nullptr;    // ponteiro para caminho (inicialmente vazio)
    tamanhoCaminho = 0;

    // Verificação básica de validade dos vértices
    if (inicio < 0 || inicio >= numVertices || fim < 0 || fim >= numVertices) {
        return caminho;  // retorna nullptr se inválido
    }

    // Caso especial: caminho do vértice para ele mesmo
    if (inicio == fim) {
        caminho = new int[1];
        caminho[0] = inicio;
        tamanhoCaminho = 1;
        return caminho;
    }

    // Arrays para controlar os predecessores e os vértices visitados
    int* predecessores = new int[numVertices];
    bool* visitados = new bool[numVertices];

    // Inicialização: -1 para predecessores e false para visitados
    for (int i = 0; i < numVertices; i++) {
        predecessores[i] = -1;
        visitados[i] = false;
    }

    // Fila para BFS implementada como array circular simples
    int* fila = new int[numVertices];
    int frente = 0, tras = 0;

    // Inicia a busca adicionando o vértice inicial à fila
    fila[tras++] = inicio;
    visitados[inicio] = true;

    bool encontrou = false;  // flag para indicar se achou o destino

    // Loop principal do BFS
    while (frente != tras && !encontrou) {
        int atual = fila[frente++];  // retira da fila

        // Para cada vizinho do vértice atual
        for (int vizinho = 0; vizinho < numVertices; vizinho++) {
            // Se existe aresta e o vizinho ainda não foi visitado
            if (matrizAdj[atual][vizinho] != 0 && !visitados[vizinho]) {
                visitados[vizinho] = true;
                predecessores[vizinho] = atual;  // marca de onde veio
                fila[tras++] = vizinho;

                // Se chegou no destino, para a busca
                if (vizinho == fim) {
                    encontrou = true;
                    break;
                }
            }
        }
    }

    if (encontrou) {
        // Conta quantos vértices tem o caminho
        int contador = 0;
        for (int no = fim; no != -1; no = predecessores[no]) {
            contador++;
        }

        // Aloca o array do caminho, tamanho igual ao contador
        caminho = new int[contador];
        tamanhoCaminho = contador;

        // Preenche o caminho do fim para o início
        int indice = contador - 1;
        for (int no = fim; no != -1; no = predecessores[no]) {
            caminho[indice--] = no;
        }
    }

    // Libera a memória temporária usada
    delete[] predecessores;
    delete[] visitados;
    delete[] fila;

    return caminho;
}
