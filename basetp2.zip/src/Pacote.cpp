#include "Pacote.hpp"
#include <string>
#include <stdexcept>
#include <sstream>

// Construtor do Pacote, inicializa os atributos
Pacote::Pacote(int id, double tempoPostagem, int origem, int destino) 
    : tempoDeChegada(tempoPostagem),   // Tempo de postagem/chegada
      armazemDestino(destino),         // Armazém de destino
      armazemOrigem(origem),           // Armazém de origem
      armazemAtual(origem),            // Inicialmente, está no armazém de origem
      idPacote(id),                    // ID único do pacote
      estado(NAO_POSTADO),             // Estado inicial: não postado
      rearmazenamentos(0)              // Contador de rearmazenamentos, inicia em 0
{ 
    // Corpo vazio. Toda a inicialização foi feita na lista de inicialização acima.
}

// Retorna o estado atual do pacote
short Pacote::getEstado() {
    return this->estado;
}

// Retorna o ID do pacote
int Pacote::getIdPacote() {
    return this->idPacote;
}

// Retorna o armazém de origem do pacote
int Pacote::getOrigem() {
    return this->armazemOrigem;
}

// Retorna o armazém destino do pacote
int Pacote::getDestino() {
    return this->armazemDestino;
}

// Atualiza o estado do pacote
void Pacote::setEstado(short estado) {
    // Garante que só aceita os estados válidos definidos em Pacote.hpp
    if (estado < NAO_POSTADO || estado > ENTREGUE) {
        throw std::invalid_argument("Estado de pacote inválido!");
    }
    this->estado = estado;
}

// Atualiza o armazém onde o pacote está atualmente
void Pacote::setArmazem(int atual) {
    this->armazemAtual = atual;
}

// Retorna o armazém onde o pacote está atualmente
int Pacote::getArmazem() {
    return this->armazemAtual;
}

// Retorna o número de rearmazenamentos do pacote
int Pacote::getRearmazenamentos() const {
    return rearmazenamentos;
}

void Pacote::setRearmazenamentos(int r) {
    rearmazenamentos = r;
}

void Pacote::incrementaRearmazenamentos() {
    rearmazenamentos++;
}

// Setter para o tempo de chegada (necessário para ajustes durante a simulação)
void Pacote::setTempoDeChegada(double tempo) {
    this->tempoDeChegada = tempo;
}

// Destrutor do pacote (aqui vazio, mas reservado para futuras expansões)
Pacote::~Pacote() {}