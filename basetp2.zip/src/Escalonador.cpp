#include "Escalonador.hpp"

Escalonador::Escalonador() : inicio(nullptr) {}

Escalonador::~Escalonador() {
    inicializa();
}

void Escalonador::inicializa() {
    while (inicio) {
        EventoEscalonador* tmp = inicio;
        inicio = inicio->prox;
        delete tmp;
    }
}

void Escalonador::insereEvento(int tempo, TipoEvento tipo, int origem, int destino, void* dado) {
    EventoEscalonador* novo = new EventoEscalonador{tempo, tipo, origem, destino, dado, nullptr};
    if (!inicio || tempo < inicio->tempo) {
        novo->prox = inicio;
        inicio = novo;
        return;
    }
    EventoEscalonador* atual = inicio;
    while (atual->prox && atual->prox->tempo <= tempo) {
        atual = atual->prox;
    }
    novo->prox = atual->prox;
    atual->prox = novo;
}

bool Escalonador::temEvento() const {
    return inicio != nullptr;
}

EventoEscalonador* Escalonador::retiraProximoEvento() {
    if (!inicio) return nullptr;
    EventoEscalonador* ev = inicio;
    inicio = inicio->prox;
    ev->prox = nullptr;
    return ev;
}

void Escalonador::finaliza() {
    inicializa();
}