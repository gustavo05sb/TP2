#include "Fila.hpp"

// Construtor da fila
// Inicializa ponteiros para nullptr e tamanho zero
template <typename T>
Fila<T>::Fila() : primeiro(nullptr), ultimo(nullptr), tam(0) {}

// Destrutor da fila
// Remove todos os elementos para liberar memória
template <typename T>
Fila<T>::~Fila() {
    while (!isVazia()) {
        pop();  // Remove cada elemento da fila
    }
}

// Método para adicionar item ao final da fila
template <typename T>
void Fila<T>::push(T item) {
    Nodo* novoNodo = new Nodo;  // Cria novo nodo
    novoNodo->item = item;      // Armazena o item
    novoNodo->proximo = nullptr; // Será o último, então aponta para nullptr
    
    if (isVazia()) {
        // Se a fila estava vazia, novo nodo é o primeiro
        primeiro = novoNodo;
    } else {
        // Caso contrário, conecta o último nodo atual ao novo
        ultimo->proximo = novoNodo;
    }
    
    // Atualiza o ponteiro para o último nodo
    ultimo = novoNodo;
    
    // Incrementa o tamanho da fila
    tam++;
}

// Método para remover e retornar o item da frente da fila
template <typename T>
T Fila<T>::pop() {
    if (isVazia()) {
        // Se tentar remover de fila vazia, lança exceção
        throw std::runtime_error("Fila vazia");
        return 0;  // nunca chega aqui por causa da exceção
    }
    
    Nodo* nodoARemover = primeiro;   // Nodo que será removido
    T item = nodoARemover->item;     // Salva o valor para retorno
    
    // Atualiza o ponteiro do primeiro para o próximo nodo
    primeiro = primeiro->proximo;
    
    // Se fila ficou vazia, último também deve ser nullptr
    if (primeiro == nullptr) {
        ultimo = nullptr;
    }
    
    delete nodoARemover;  // Libera memória do nodo removido
    tam--;                // Decrementa tamanho da fila
    
    return item;          // Retorna o item removido
}

// Verifica se a fila está vazia
template <typename T>
bool Fila<T>::isVazia() {
    return primeiro == nullptr;
}

// Retorna o tamanho atual da fila
template <typename T>
int Fila<T>::getTam() {
    return this->tam;
}

// Retorna o item que está na frente da fila sem remover
template <typename T>
T Fila<T>::frente() {
    if (isVazia()) {
        return 0; // ou poderia lançar exceção — cuidado dependendo do tipo T
    }
    return primeiro->item;
}

// Explicitamente instanciando as versões da fila para int e double
template class Fila<int>;      
template class Fila<double>;
