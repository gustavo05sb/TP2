#include "Pilha.hpp"
#include "Pacote.hpp"

// Construtor: inicializa a pilha vazia (topo nulo, zero itens)
template <typename T>
Pilha<T>::Pilha() : topo(nullptr), numItens(0) {}

// Insere (push) um novo item no topo da pilha
template <typename T>
void Pilha<T>::push(T item) {
    Nodo* novoNodo = new Nodo{item, topo};  // Cria novo nodo apontando para o topo atual
    topo = novoNodo;                        // Atualiza o topo para o novo nodo
    numItens++;                            // Incrementa o número de itens
}

// Destrutor: libera todos os nodos da pilha para evitar vazamento de memória
template <typename T>
Pilha<T>::~Pilha() {
    while (!isVazia()) {
        pop(); // Remove e libera cada nodo do topo
    }
}

// Remove e retorna o item do topo da pilha
template <typename T>
T Pilha<T>::pop() {
    if (isVazia()) {
        throw std::runtime_error("Pilha vazia!"); // Erro se tentar pop em pilha vazia
    }
    Nodo* nodoRemovido = topo;      // Nodo que será removido (topo atual)
    T item = nodoRemovido->item;    // Salva o item para retornar
    topo = nodoRemovido->proximo;   // Atualiza o topo para o próximo nodo
    delete nodoRemovido;            // Libera o nodo removido
    numItens--;                    // Decrementa a quantidade de itens

    return item;                   // Retorna o item removido
}

// Verifica se a pilha está vazia (topo nulo)
template <typename T>
bool Pilha<T>::isVazia() {
    return topo == nullptr;
}

// Retorna o número atual de itens na pilha
template <typename T>
int Pilha<T>::getTam() {
    return numItens;
}

// Retorna o item do topo sem remover. Se estiver vazia, retorna 0 (pode ser problema pra tipos não numéricos)
template <typename T>
T Pilha<T>::getTopo() {
    if(isVazia()){
        return 0;   // Atenção: retorna 0, pode não ser apropriado para todos os tipos T
    }
    return topo->item;
}

// Explicitamente instanciando os tipos usados no programa
template class Pilha<int>;         // Pilha de inteiros
template class Pilha<double>;      // Pilha de doubles
template class Pilha<Pacote*>;     // Pilha de ponteiros para Pacote
