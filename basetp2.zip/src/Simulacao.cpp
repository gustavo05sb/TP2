#include "Simulacao.hpp"

void Simulacao::executar(
    int capacidade, int latencia, int intervalo, int custo_remocao,
    int numArmazens, Armazem** armazens, int numPac, Pacote** pacs, Fila<int>* caminho
) {
    int done = 0;
    int tempo = pacs[0]->tempoDeChegada;

    while (done < numPac) {
        done = numPac;

        // Processamento dos pacotes
        for (int i = 0; i < numPac; i++) {
            if (!caminho[i].isVazia() && pacs[i]->getEstado() != ARMAZENADO && pacs[i]->getEstado() != ENTREGUE) {
                int prox = caminho[i].pop();
                armazens[prox]->armazenar(pacs[i], caminho[i].frente(), tempo + latencia);
            }
        }

        // Atualiza o tempo
        if (tempo == pacs[0]->tempoDeChegada) {
            tempo += custo_remocao;
        }
        tempo += intervalo;

        // Processamento original - mas agora o controle de capacidade será no Armazem
        for (int arm = 0; arm < numArmazens; arm++) {
            for (int sec = 0; sec < numArmazens; sec++) {
                armazens[arm]->transportarOuRearmazenar(sec, capacidade, tempo, caminho, pacs, numPac);
            }
        }

        // Verifica quantos ainda estão pendentes
        for (int i = 0; i < numPac; i++) {
            if (pacs[i]->getEstado() != ENTREGUE && !caminho[i].isVazia()) {
                done--;
            }
        }
    }
}