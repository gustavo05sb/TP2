#include "Armazem.hpp"
#include "Evento.hpp"
#include "Fila.hpp"
#include <queue>

// Construtor
Armazem::Armazem(int id, int numSecoes)
    : idArmazem(id), numSecoes(numSecoes), quantPacs(0)
{
    secoes = new Pilha<Pacote*>[numSecoes];
}

// Destrutor
Armazem::~Armazem()
{
    delete[] secoes;
}

// Armazena um pacote
void Armazem::armazenar(Pacote* pacote, int secaoDestino, int tempo, bool rearm) {
    if (!pacote) return;
    
    if (rearm) {
        pacote->incrementaRearmazenamentos();
    }

    if (pacote->getEstado() == NAO_POSTADO) {
        tempo = pacote->tempoDeChegada;
    }

    pacote->setArmazem(idArmazem);

    if (pacote->getDestino() == idArmazem) {
        pacote->setEstado(ENTREGUE);
        secoes[secaoDestino].push(pacote);
        quantPacs++;
        Evento::imprimirEntregue(tempo, pacote, idArmazem);
    } else {
        pacote->setEstado(ARMAZENADO);
        Evento::imprimirArmazenado(tempo, pacote, idArmazem, secaoDestino, rearm);
        secoes[secaoDestino].push(pacote);
        quantPacs++;
    }
}

// Remove um pacote
Pacote* Armazem::remover(int secaoOrigem, int tempo, int proximoArmazem)
{
    if (secoes[secaoOrigem].isVazia())
    {
        return nullptr;
    }

    Pacote* pacote = secoes[secaoOrigem].pop();

    if (pacote && pacote->getEstado() != ENTREGUE)
    {
        pacote->setEstado(TRANSPORTE);

        Evento::imprimirRemovido(tempo, pacote, idArmazem, secaoOrigem);
        Evento::imprimirTransporte(tempo, pacote, idArmazem, proximoArmazem);

        quantPacs--;
    }

    return pacote;
}

// Verifica se tem pacote
bool Armazem::temPacote() const
{
    return quantPacs > 0;
}

// Retorna ID do armazém
int Armazem::getId() const
{
    return idArmazem;
}

void Armazem::removerTodosPendentes(int tempo) {
    for (int secao = 0; secao < numSecoes; secao++) {
        while (!secoes[secao].isVazia()) {
            Pacote* pacote = secoes[secao].getTopo();
            if (pacote->getEstado() != ENTREGUE && pacote->getEstado() != TRANSPORTE) {
                // Passa o destino do pacote como próximo armazém
                remover(secao, tempo, pacote->getDestino());
            } else {
                break;
            }
        }
    }
}

void Armazem::transportarOuRearmazenar(int secaoOrigem, int capacidade, int tempo, Fila<int>* caminho, Pacote** pacs, int numPac)
{
    int qtdTransportados = 0;
    Pilha<Pacote*> tempStack;

    // Retira todos os pacotes da pilha (do topo para o fundo)
    while (!secoes[secaoOrigem].isVazia()) {
        tempStack.push(secoes[secaoOrigem].pop());
    }

    // Fila para manter ordem FIFO
    std::queue<Pacote*> filaPacotes;
    while (!tempStack.isVazia()) {
        filaPacotes.push(tempStack.pop());
    }

    int tempoRemocao = tempo; // tempo base para o primeiro pacote removido da seção
    int tempoUltimoTransporte = tempo; // para guardar o tempo do último transporte

    // Transporte
    while (!filaPacotes.empty() && qtdTransportados < capacidade) {
        Pacote* pacote = filaPacotes.front();
        filaPacotes.pop();

        // Descobre o índice do pacote no vetor pacs
        int idxPacote = -1;
        for (int idx = 0; idx < numPac; idx++) {
            if (pacs[idx] == pacote) {
                idxPacote = idx;
                break;
            }
        }

        // Descobre o próximo armazém real do caminho
        int proximoArmazem = pacote->getDestino();
        if (idxPacote != -1 && !caminho[idxPacote].isVazia()) {
            proximoArmazem = caminho[idxPacote].frente();
        }

        int tempoEvento = tempoRemocao + pacote->getRearmazenamentos();
        tempoUltimoTransporte = tempoEvento; // atualiza para o último transporte

        if (pacote && pacote->getEstado() != ENTREGUE) {
            pacote->setEstado(TRANSPORTE);
            Evento::imprimirRemovido(tempoEvento, pacote, idArmazem, secaoOrigem);
            Evento::imprimirTransporte(tempoEvento, pacote, idArmazem, proximoArmazem);
            quantPacs--;
        }
        qtdTransportados++;
    }

    // Todos os excedentes vão para rearmazenamento no tempo do último transporte (ou tempo base se nenhum foi transportado)
    int tempoRearmazenamento = (qtdTransportados > 0) ? tempoUltimoTransporte : tempo;
    while (!filaPacotes.empty()) {
        Pacote* pacote = filaPacotes.front();
        filaPacotes.pop();
        int tempoEvento = tempoRearmazenamento + pacote->getRearmazenamentos();
        armazenar(pacote, secaoOrigem, tempoEvento, true);
    }
}