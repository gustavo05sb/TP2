#ifndef FILA_HPP
#define FILA_HPP

#include <stdexcept> // Para exceções padrão, como std::runtime_error

// Definição da classe template Fila (estrutura de dados FIFO - First In, First Out)
template <typename T>
class Fila {
public:
    // Construtor padrão
    Fila();

    // Destrutor (libera memória dos nós)
    ~Fila();

    // Insere um item no final da fila
    void push(T item);

    // Remove e retorna o item do início da fila
    T pop();

    // Verifica se a fila está vazia
    bool isVazia();

    // Retorna o tamanho atual da fila
    int getTam();

    // Retorna o item da frente (sem remover)
    T frente();

private:
    // Definição interna da estrutura Nodo (nó da fila)
    struct Nodo {
        T item;        // Item armazenado no nó
        Nodo* proximo; // Ponteiro para o próximo nó na fila
    };

    Nodo* primeiro;  // Ponteiro para o primeiro nó (início da fila)
    Nodo* ultimo;    // Ponteiro para o último nó (final da fila)
    int tam;         // Tamanho da fila (quantidade de elementos)
};

#endif
