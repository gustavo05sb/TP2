#ifndef PACOTE_HPP
#define PACOTE_HPP

#include <string>
#include <iostream>
#include <iomanip>

// Definição dos possíveis estados do pacote
#define NAO_POSTADO 1   // Pacote ainda não foi postado
#define POSTADO 2       // Chegada escalonada a um armazém (postagem ou transporte)
#define ARMAZENADO 3    // Armazenado na seção associada ao próximo destino de um armazém
#define TRANSPORTE 4    // Removido da seção para transporte
#define ENTREGUE 5      // Pacote foi entregue ao destino final

class Pacote {
public:
    // Construtor: recebe ID, tempo de postagem, origem e destino do pacote
    Pacote(int id, double tempoPostagem, int origem, int destino);

    // Destrutor
    ~Pacote();

    int getRearmazenamentos() const;
    void setRearmazenamentos(int r);
    void incrementaRearmazenamentos();

    // Getters e setters para o estado do pacote
    short getEstado();
    void setEstado(short estado);

    // Getter para o ID do pacote
    int getIdPacote();

    // Getters para origem e destino (armazéns)
    int getOrigem();
    int getDestino();

    // Getters e setters para armazém atual (onde o pacote está)
    int getArmazem();
    void setArmazem(int atual);

    // Tempo em que o pacote chega (momento de postagem)
    double tempoDeChegada;
    
    // Setter para o tempo de chegada (necessário para ajustes de tempo)
    void setTempoDeChegada(double tempo);

private:
    int armazemDestino;   // ID do armazém destino do pacote
    int armazemOrigem;    // ID do armazém de origem do pacote
    int armazemAtual;     // ID do armazém onde o pacote está atualmente
    int idPacote;         // Identificador único do pacote
    short estado;         // Estado atual do pacote (usando as constantes definidas)
    int rearmazenamentos; // Contador de rearmazenamentos do pacote
};
#endif // PACOTE_HPP
