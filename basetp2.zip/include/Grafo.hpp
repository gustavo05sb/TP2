#ifndef GRAFO_HPP
#define GRAFO_HPP

#include "Pilha.hpp" // Dependência para operações que usam Pilha (se houver)
#include "Fila.hpp"  // Dependência para buscas ou percursos em largura (BFS)

// Definição da classe Grafo (implementação baseada em matriz de adjacência)
class Grafo {
private:
    int **matrizAdj; // Matriz de adjacência: representa as conexões entre os vértices
    int numVertices; // Quantidade de vértices do grafo

public:
    // Construtor: inicializa a matriz de adjacência com o número de vértices informado
    Grafo(int numVertices);

    // Destrutor: libera a memória alocada pela matriz
    ~Grafo();

    // Adiciona uma aresta de 'origem' para 'destino' com peso (padrão = 1)
    void adicionarAresta(int origem, int destino, int peso = 1);

    // Remove a aresta de 'origem' para 'destino'
    void removerAresta(int origem, int destino);

    // Imprime a matriz de adjacência na tela
    void imprimirMatriz();

    // Verifica se existe uma aresta de 'origem' para 'destino'
    bool existeAresta(int origem, int destino);

    // Calcula o menor caminho entre 'inicio' e 'fim'
    // Retorna um vetor com o caminho e altera 'tamanhoCaminho' com o tamanho do caminho encontrado
    int* menorCaminho(int inicio, int fim, int& tamanhoCaminho);
};

#endif
