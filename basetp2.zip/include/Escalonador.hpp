#ifndef ESCALONADOR_HPP
#define ESCALONADOR_HPP

#pragma once

// Enum para tipos de eventos
enum class TipoEvento { EVENTO_TRANSPORTE, EVENTO_CHEGADA_PACOTE };

// Estrutura de evento
struct EventoEscalonador {
    int tempo;
    TipoEvento tipo;
    int origem;
    int destino;
    void* dado; // ponteiro genérico para pacote ou outro dado
    EventoEscalonador* prox;
};

class Escalonador {
private:
    EventoEscalonador* inicio;
public:
    Escalonador();
    ~Escalonador();

    void inicializa();
    void insereEvento(int tempo, TipoEvento tipo, int origem, int destino, void* dado);
    bool temEvento() const;
    EventoEscalonador* retiraProximoEvento();
    void finaliza();
};

#endif