#ifndef ARMAZEM_HPP
#define ARMAZEM_HPP

#include <string>
#include <stdexcept>
#include "Pilha.hpp"
#include "Pacote.hpp"
#include "Fila.hpp"

class Armazem {
public:
    Armazem(int id, int numSecoes);
    ~Armazem();
    
    Pilha<Pacote*>* getSecoes() { return secoes; }
    Pilha<Pacote*>& getSecao(int idx) { return secoes[idx]; }
    
    void transportarOuRearmazenar(int secaoOrigem, int capacidade, int tempo, Fila<int>* caminho, Pacote** pacs, int numPac);

    void armazenar(Pacote* pacote, int secaoDestino, int tempo, bool rearm = false);
    Pacote* remover(int secao, int tempo, int proximoArmazem);
    
    void removerTodosPendentes(int tempo);
    int getId() const;
    bool temPacote() const;

private:
    int idArmazem;        // ID do armazém
    int numSecoes;        // Quantidade de seções no armazém
    int quantPacs;        // Quantidade de pacotes armazenados

    Pilha<Pacote*>* secoes;  // Vetor de pilhas (uma pilha por seção)
};

#endif