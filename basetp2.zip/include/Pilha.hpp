#ifndef PILHA_HPP
#define PILHA_HPP

#include <stdexcept>

template <typename T>
class Pilha {
public:
    // Construtor: inicializa a pilha vazia
    Pilha();

    // Destrutor: libera memória alocada
    ~Pilha();

    // Adiciona um item no topo da pilha
    void push(T item);

    // Remove e retorna o item do topo da pilha
    T pop();

    // Verifica se a pilha está vazia
    bool isVazia();

    // Retorna o número de itens na pilha
    int getTam();

    // Retorna o item que está no topo, sem remover
    T getTopo();

private:
    // Nodo interno para representar cada elemento da pilha
    struct Nodo {
        T item;       // Valor armazenado
        Nodo* proximo; // Ponteiro para o próximo nodo (abaixo na pilha)
    };

    Nodo* topo;      // Ponteiro para o topo da pilha
    int numItens;    // Quantidade de itens na pilha
};

#endif
