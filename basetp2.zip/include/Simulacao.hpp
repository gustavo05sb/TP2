#ifndef SIMULACAO_HPP
#define SIMULACAO_HPP

#pragma once
#include "Pacote.hpp"
#include "Armazem.hpp"
#include "Fila.hpp"

class Simulacao {
public:
    // Construtor padrão
    Simulacao() {}

    void executar(
        int capacidade, int latencia, int intervalo, int custo_remocao,
        int numArmazens, Armazem** armazens, int numPac, Pacote** pacs, Fila<int>* caminho
    );
};

#endif