#ifndef EVENTO_HPP
#define EVENTO_HPP

#include "Pacote.hpp"

class Evento {
public:
    static void imprimirArmazenado(int tempo, Pacote* pacote, int idArmazem, int secao, bool rearm);
    static void imprimirEntregue(int tempo, Pacote* pacote, int idArmazem);
    static void imprimirRemovido(int tempo, Pacote* pacote, int idArmazem, int secao);
    static void imprimirTransporte(int tempo, Pacote* pacote, int idArmazem, int proximoArmazem);
};

#endif // EVENTO_HPP